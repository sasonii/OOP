package tests;

public class EmptyA {
}
