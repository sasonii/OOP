//
// Created by Dell on 27/06/2023.
//

#ifndef HW5_CELLTYPE_H
#define HW5_CELLTYPE_H

enum CellType {EMPTY, X, A, B, C, D, E, F, G, H, I, J, K, O, P, Q, R};

#endif //HW5_CELLTYPE_H
