package tests;

public class NotShortCircuitException extends Exception {
}
