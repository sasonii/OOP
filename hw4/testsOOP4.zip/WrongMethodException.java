package tests;

public class WrongMethodException extends Exception {
}
