package ourTests;

public class TestSudoNew
{
}
