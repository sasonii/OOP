//
// Created by Dell on 27/06/2023.
//

#ifndef HW5_DIRECTION_H
#define HW5_DIRECTION_H

enum Direction {
    UP = 0,
    DOWN = 1,
    LEFT = 2,
    RIGHT = 3
};

#endif //HW5_DIRECTION_H
