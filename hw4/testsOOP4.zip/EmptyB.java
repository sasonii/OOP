package tests;

public class EmptyB extends EmptyA {
}

